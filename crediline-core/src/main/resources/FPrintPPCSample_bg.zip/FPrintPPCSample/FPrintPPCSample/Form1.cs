#region Using directives

using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

#endregion

namespace FPrintPPCSample
{

    /// <summary>
    /// Summary description for form.
    /// </summary>
    public class Form1 : System.Windows.Forms.Form
    {
        private const UInt32 STILL_ACTIVE = 0x00000103;

        private Button button1;
        /// <summary>
        /// Main menu for the form.
        /// </summary>
        private System.Windows.Forms.MainMenu mainMenu1;

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.button1 = new System.Windows.Forms.Button();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, 32);
            this.button1.Size = new System.Drawing.Size(234, 23);
            this.button1.Text = "Click to print sample";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.button1);
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Text = "FPrintPPC Sample";

        }

        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            Application.Run(new Form1());
        }

        [DllImport("coredll.dll", SetLastError = true)]
        static extern bool CreateProcess(String imageName,
                                         String cmdLine,
                                         IntPtr lpProcessAttributes,
                                         IntPtr lpThreadAttributes,
                                         bool boolInheritHandles,
                                         Int32 dwCreationFlags,
                                         IntPtr lpEnvironment,
                                         IntPtr lpszCurrentDir,
                                         byte[] si,
                                         ProcessInfo pi);

        [DllImport("coredll.dll", SetLastError = true)]
        static extern bool GetExitCodeProcess(IntPtr hProcess, ref UInt32 lpExitCode);


        private void button1_Click(object sender, EventArgs e)
        {
            ProcessInfo FPrintPPCPI = new ProcessInfo();

            string process = "\\Program Files\\Datecs Applications\\FPrintPPC\\FPrintPPC.exe";
            string cmd_line = "\\sample.txt";
            byte[] si = new byte[128];

            CreateProcess(process, cmd_line, IntPtr.Zero, IntPtr.Zero, false, 0, IntPtr.Zero, IntPtr.Zero, si, FPrintPPCPI);

            UInt32 ec = 0;
            Cursor.Current = Cursors.WaitCursor;
            for (; ; )
            {
                GetExitCodeProcess(FPrintPPCPI.hProcess, ref ec);
                if (ec == STILL_ACTIVE)
                    System.Threading.Thread.Sleep(300);
                else
                    break;
            }
            Cursor.Current = Cursors.Default;

            MessageBox.Show("Exit code: " + ((int)ec).ToString());
        }

    }



    //User defined Process info structure
    public class ProcessInfo
    {
        public IntPtr hProcess;
        public IntPtr hThread;
        public Int32 ProcessId;
        public Int32 ThreadId;
    }
}

